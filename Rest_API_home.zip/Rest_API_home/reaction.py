class User:
    def __init__(self, reaction_id: str, post_id, user_id: str, reaction_type  ):
        self.username = reaction_id
        self.username = post_id
        self.username = user_id
        self.username = reaction_type