class Reaction:
    def __init__(self, reaction_id, post_id, user_id, reaction_type):
        self.reaction_id = reaction_id
        self.post_id = post_id
        self.user_id = user_id
        self.reaction_type = reaction_type